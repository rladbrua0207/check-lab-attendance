export const globalTheme = {
    blueColor: "#6586F9",
    redColor: "#df5a61",
};