import { atom } from "recoil";
import { format } from "date-fns";

export const selectedCalendarDateAtom = atom({
  key: "selectedCalendarDate",
  default: format(new Date(), "yyMMdd"),
});

export const userLocationAtom = atom({
  key: "userLocation",
  default: { lat: 0, lon: 0 },
});

export const isLoginAtom = atom({
  key: "isLogin",
  default: false,
});

export const statisticSelectedDateMenuAtom = atom({
  key: "statisticSelectedDateMenu",
  default: "year",
});
